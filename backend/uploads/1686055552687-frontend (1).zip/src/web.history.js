var history = require("history").createBrowserHistory;

const browserhistory = history();

export default browserhistory;
