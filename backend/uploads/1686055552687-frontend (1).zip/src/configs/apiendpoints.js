const apiendpoints = {
  login: "/v1/login",
  upload: "/v1/file/upload",
  termsAndConditions: "/v1/terms/search",
  acceptTermsAndConditions: "/v1/terms/accept",
  search: "/v1/upload/search"
};

export default apiendpoints;
