import { createTheme } from "@material-ui/core/styles";

const themeDefault = createTheme({
  typography: {
    fontFamily: '"Roboto"',
    fontWeight: "400",
  },
  overrides: {
    MuiDropzoneArea: {
      root: {
        // display:'flex',
        justifyContent: "center",
        alignItems: "center",
        top: "auto",
        width: "50%",
        borderColor: "#1C9AB7",
        backgroundColor: "#F5F9FA",
        border: "1px dashed #1C9AB7",
        fontColor: "#1C9AB7",
        marginTop: "3%",
        marginLeft: "1%",
        "& svg": { color: "#1C9AB7" },
        "& p": {
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
          overflow: "hidden",
          fontSize: "19px",
          color: "#1C9AB7",
        },
      },
    },
    MuiDropzonePreviewList: {
      image: {
        maxWidth: "60%",
      },
    },
    MuiInputBase:  {
       fullWidth: { 
         width: "80%" 
        } 
      },
    MuiTableRow: {
      root: {
        height: "60px",
        margin: "10px",
        cursor: "pointer",
        "&$hover:hover:nth-child(odd)": { backgroundColor: "#D6EAF8" },
        "&$hover:hover:nth-child(even)": { backgroundColor: "#E9F7EF" },
      },
    },
    MUIDataTableBodyRow: {
      root: {
        "&:nth-child(odd)": {
          backgroundColor: "#D6EAF8",
        },
        "&:nth-child(even)": {
          backgroundColor: "#E9F7EF",
        },
      },
    },
    MUIDataTableFilterList: {
      chip: {
        display: "none",
      },
    },
    MuiMenu: {
      list: {
        minWidth: "210px",
      },
    },
    MuiMenuItem: {
      root: {
        "@media (max-width:670px)": {
          fontSize: "0.875rem",
        },
      },
    },
    MUIDataTableFilter: {
      root: {
        backgroundColor: "white",
        width: "80%",
        fontFamily: '"Roboto" ,sans-serif',
      },
      checkboxFormControl: {
        minWidth: "200px",
      },
    },
    MuiList: {
      root: {
        fontFamily: '"Roboto" ,sans-serif',
      },
      padding: {
        "@media (max-width:670px)": {
          padding: "0px",
          paddingLeft: "9px",
        },
      },
    },
    MUIDataTable: {
      paper: {
        minHeight: "674px",
        boxShadow: "0px 0px 2px #00000029",
        border: "1px solid #0000001F",
      },
      responsiveBase: {
        minHeight: "560px",
      },
    },
    MUIDataTableToolbar: {
      filterPaper: {
        width: "310px",
      },
      MuiButton: {
        root: {
          display: "none",
        },
      },
    },
    MuiGrid: {
      grid: {
        maxWidth: "100%",
      },
    },

    MuiTableCell: {
      head: {
        padding: ".6rem .5rem .6rem 1.5rem",
        backgroundColor: "#F8F8FA !important",
        marginLeft: "25px",
        letterSpacing: "0.74",
        fontWeight: "bold",
        minHeight: "700px",
      },
    },
    MUIDataTableHeadCell: {
      root: {
        width: "16%",
        
      },
    },
    MuiPaper: {
      root: {
        boxShadow: "none !important",
        borderRadius: 0,
        border: "1px solid rgb(224 224 224)",
      },
    },
    MuiDialog: {
      paper: { minWidth: "360px", minHeight: "116px" },
    },
    MuiAppBar: {
      root: {
        boxSizing: "border-box",
        margin: "-1px",
        padding: "0px",
      },
    },
    MuiToolbar: {
      root: {
        padding: 0,
      },
    },
    MuiFormControlLabel: {
      root: {
        height: "auto",
        marginBottom: "25px"
      },
      label: {
        fontFamily: '"Roboto" ,sans-serif',
        fontSize: "0.875rem",
        "@media (max-width:640px)": {
          fontSize: "10px",
        },
      },
    },

    MUIDataTableBodyCell: {
      root: { padding: ".5rem .5rem .5rem .8rem", textTransform: "capitalize" },
    },
    MuiButton: {
      root: {
        minWidth: "25",
        borderRadius: "none",
      },
      label: {
        textTransform: "none",
        fontFamily: '"Roboto", "Segoe UI"',
        fontSize: "16px",
        letterSpacing: "0.16px",
        textAlign: "center",
        display: "flex",
        justifyContent: "center",
        height: "19px",
        "@media (max-width:640px)": {
          fontSize: "10px",
        },
      },
      sizeLarge: {
        height: "40px",
        borderRadius: "20px",
      },
      sizeMedium: {
        height: "40px",
        borderRadius: "20px",
      },
      sizeSmall: {
        height: "30px",
        borderRadius: "20px",
      },
    },
    MuiTabs: {
      indicator: {
        backgroundColor: "#FD7F23",
      },
    },
    MuiTab: {
      root: {
        width: "auto",
        fontSize: "18px",
        fontWeight: "300",
        letterSpacing: "0px",
        fontFamily: "Roboto",
        padding: "0",
        marginRight: "28px",
        "@media (min-width:600px)": {
          minWidth: "auto",
        },
        "@media (max-width:600px)": {
          marginRight: "20px",
          minWidth: "auto",
        },
        "@media (max-width:550px)": {
          fontSize: "1rem",
        },
      },
      textColorInherit: {
        color: "#3A3A3A",
        opacity: 1,
        "&.Mui-selected": {
          fontWeight: "bold",
        },
      },
      wrapper: {
        alignItems: "flex-start",
        textTransform: "none",
      },
    },
    MuiBox: {
      root: {
        padding: "24px 0px",
      },
    },
  },
  palette: {
    primary: {
      light: "#60568d",
      main: "#2C2799",
      dark: "#271e4f",
      contrastText: "#FFFFFF",
    },
    secondary: {
      light: "#FFFFFF",
      main: "#FFFFFF",
      dark: "#FFFFFF",
      contrastText: "#000000",
    },
    background: {
      default: "#2C2799",
    },
  },
});

themeDefault.typography.h1 = {
  fontSize: "3.125rem",
  fontFamily: '"Rowdies", cursive,"Roboto" ,sans-serif',
  fontWeight: "300",
  "@media (max-width:550px)": {
    fontSize: "2rem",
  },
};
themeDefault.typography.h2 = {
  fontSize: "2.5rem",
  fontFamily: '"Rowdies", cursive,"Roboto" ,sans-serif',
  fontWeight: "300",
  "@media (max-width:550px)": {
    fontSize: "1.5rem",
  },
};
themeDefault.typography.h3 = {
  fontSize: "1.6875rem",
  fontFamily: '"Rowdies", cursive,"Roboto" ,sans-serif',
  fontWeight: "300",
  letterSpacing: "0px",
  "@media (max-width:550px)": {
    fontSize: "1.3rem",
  },
};
themeDefault.typography.h4 = {
  fontSize: "1.5rem",
  fontFamily: '"Rowdies", cursive,"Roboto" ,sans-serif',
  fontWeight: "300",
  "@media (max-width:550px)": {
    fontSize: "0.9rem",
  },
};
themeDefault.typography.h5 = {
  fontSize: "1.3125rem",
  fontFamily: '"Rowdies", cursive,"Roboto" ,sans-serif',
  fontWeight: "300",
  "@media (max-width:550px)": {
    fontSize: "1rem",
  },
};
themeDefault.typography.h6 = {
  fontSize: "1.125rem",
  fontFamily: '"Rowdies", cursive,"Roboto" ,sans-serif',
  fontWeight: "300",
  paddingTop: "4px",
  "@media (max-width:550px)": {
    fontSize: "1rem",
  },
};
themeDefault.typography.body1 = {
  fontSize: "1.25rem",
  fontFamily: '"Roboto", sans-serif ,sans-serif',
  fontWeight: "400",
};
themeDefault.typography.body2 = {
  fontSize: "0.875rem",
  fontFamily: '"Roboto", sans-serif',
  fontWeight: "400",
  color: "#0C0F0F",
  lineHeight: "22px",
};
themeDefault.typography.caption = {
  fontSize: "0.75rem",
  fontFamily: "'Roboto', sans-serif",
  fontWeight: "400",
};
themeDefault.typography.subtitle1 = {
  fontSize: "1.125rem",
  fontFamily: "'Roboto', sans-serif",
  fontWeight: "400",
  "@media (max-width:550px)": {
    fontSize: ".9rem",
  },
};
themeDefault.typography.subtitle2 = {
  fontSize: "1rem",
  fontFamily: '"Rowdies", cursive,"Roboto" ,sans-serif',
  fontWeight: "300",
  "@media (max-width:550px)": {
    fontSize: ".7rem",
  },
};

export default themeDefault;
